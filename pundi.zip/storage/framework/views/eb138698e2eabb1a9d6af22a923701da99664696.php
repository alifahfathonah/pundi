<nav>                  
    <ul id="navigation">    
        <li>
            <a href="#">Ulasan</a>
            <ul class="submenu">
                <?php $__currentLoopData = $sub_headline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('sub_kategori','sub_kategori='.$i->id)); ?>"><?php echo e($i->n_sub_kategori); ?></a></li>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <li>
            <a href="#">Kajian</a>
            <ul class="submenu">
                <?php $__currentLoopData = $sub_indepth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('sub_kategori','sub_kategori='.$i->id)); ?>"><?php echo e($i->n_sub_kategori); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <li>
            <a href="#">Kreativitas</a>
            <ul class="submenu">
                <?php $__currentLoopData = $sub_kebijakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('sub_kategori','sub_kategori='.$i->id)); ?>"><?php echo e($i->n_sub_kategori); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <li>
            <a href="#">Serba serbi</a>
            <ul class="submenu">
                <?php $__currentLoopData = $sub_serbaSerbi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('sub_kategori','sub_kategori='.$i->id)); ?>"><?php echo e($i->n_sub_kategori); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <li>
            <a href="<?php echo e(route('konsultasi')); ?>">Konsultasi</a>
        </li>
        <?php if(Auth::user() != null): ?>
        <li>
            <a href="#">Akun</a>
            <ul class="submenu">
                <li><a href="<?php echo e(route('profil')); ?>">Edit Profil</a></li>
                <li><a href="<?php echo e(route('kirim-tulisan')); ?>">Kirim Tulisan</a></li>
                <li><a href="<?php echo e(url('ketentuan-tulisan')); ?>">Ketentuan Tulisan</a></li>
                <li><a href="" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Log Out</a></li>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </ul>
        </li>
        <?php else: ?> 
        <li>
            <a href="#">Akun</a>
            <ul class="submenu">
                <li><a href="<?php echo e(route('kirim-tulisan')); ?>">Kirim Tulisan</a></li>
                <li><a href="<?php echo e(url('ketentuan-tulisan')); ?>">Ketentuan Tulisan</a></li>
                <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
            </ul>
        </li>
        <?php endif; ?>
        <li>
            <form class="form-row d-flex justify-content-center md-form form-sm mt-1" action="<?php echo e(route('hasil-pencarian')); ?>" method="GET">
                <div class="input-group input-group-lg" style="margin-left: 6%">
                    <input type="text" class="single-input-primary2" name="hasil_search" style="width: 82%"  placeholder="Search Keyword">
                    <div class="input-group-prepend" style="background: #FEBD01;">
                        <button type="submit" style="border: none; background: #FEBD01; width: 50px">
                            <i class="fa fa-search" style="color: white"></i> 
                        </button>
                    </div>
                </div>
            </form>
        </li>
    </ul>
</nav>
<?php /**PATH E:\xampp\htdocs\2020\pundi\resources\views/masterPages/headers/nav-mobile.blade.php ENDPATH**/ ?>