<div class="comments-area -mb-50">
    <p class="fs-24 f-b f-blk -mt-30"><?php echo e($komen->count()); ?> komentar</p>
    <?php $__currentLoopData = $komen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="comment-list">
        <div class="single-comment justify-content-between d-flex">
            <div class="user justify-content-between d-flex">
                <div class="thumb">
                    <?php if($i->user_id != null): ?>
                    <img src="<?php echo e(asset('ava/' .$i->user->photo)); ?>" alt="photo">
                    <?php else: ?>
                    <img src="<?php echo e(config('app.path_url').'ava/user.png'); ?>" alt="photo">
                    <?php endif; ?>
                </div>
                <div class="desc">
                    <p class="comment">
                        <?php echo e($i->comment); ?>

                    </p>
                    <div class="d-flex justify-content-between">
                        <div class="d-flex align-items-center">
                            <h5>
                                <a href="#"><?php echo e($i->nama); ?></a>
                            </h5>
                            <i class="fas fa-clock fa-xs m-l-20 text-grey -mr-10"></i>
                            <span class="date" ><?php echo e($i->created_at); ?></span>
                        </div>
                        <div class="reply-btn">
                            <a href="#" class="btn-reply text-uppercase">reply</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH E:\xampp\htdocs\2020\pundi\resources\views/pages/artikel/komen.blade.php ENDPATH**/ ?>