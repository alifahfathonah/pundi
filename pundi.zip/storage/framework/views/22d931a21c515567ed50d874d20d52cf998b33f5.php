<div>
    <p class="fs-24 f-b f-blk" style="margin-top: -20px">Related Post</p>
</div><?php /**PATH E:\xampp\htdocs\2020\pundi\resources\views/pages/artikel/related-artikel.blade.php ENDPATH**/ ?>