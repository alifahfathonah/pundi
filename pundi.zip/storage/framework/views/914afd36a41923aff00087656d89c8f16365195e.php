<?php $__env->startSection('content'); ?>
    <div>
        <!-- Header -->
        <?php echo $__env->make('masterPages.headers.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Section 1 : Trending Section -->
        <?php echo $__env->make('pages.includes.trending', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Section 2 : Indepth Of Issues --> 
        <?php echo $__env->make('pages.includes.indepth-of-issues', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Section 3 : Berita Terbaru -->
        <?php echo $__env->make('pages.includes.berita-terbaru', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Section 4 : Report -->
        <?php echo $__env->make('pages.includes.report', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <!-- Footer -->
        <?php echo $__env->make('masterPages.footers.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\2020\pundi\resources\views/home.blade.php ENDPATH**/ ?>