<nav>                  
    <ul>    
        <li>
            <a href="<?php echo e(route('kategori','kategori=1')); ?>" style="font-size: 13px !important">ULASAN <span class="fa fa-angle-down "></span></a>
            <ul class="submenu">
                <?php $__currentLoopData = $sub_headline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('sub_kategori','sub_kategori='.$i->id)); ?>"><?php echo e($i->n_sub_kategori); ?></a></li>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <li>
            <a href="<?php echo e(route('kategori','kategori=2')); ?>" style="font-size: 13px !important">KAJIAN <span class="fa fa-angle-down "></a>
            <ul class="submenu">
                <?php $__currentLoopData = $sub_indepth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('sub_kategori','sub_kategori='.$i->id)); ?>"><?php echo e($i->n_sub_kategori); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul> 
        </li>
        <li>
            <a href="<?php echo e(route('kategori','kategori=3')); ?>" style="font-size: 13px !important">KREATIVITAS <span class="fa fa-angle-down "></a>
            <ul class="submenu">
                <?php $__currentLoopData = $sub_kebijakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('sub_kategori','sub_kategori='.$i->id)); ?>"><?php echo e($i->n_sub_kategori); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <li>
            <a href="<?php echo e(route('kategori','kategori=4')); ?>" style="font-size: 13px !important">SERBA SERBI <span class="fa fa-angle-down "></a>
            <ul class="submenu">
                <?php $__currentLoopData = $sub_serbaSerbi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('sub_kategori','sub_kategori='.$i->id)); ?>"><?php echo e($i->n_sub_kategori); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <li>
            <a href="<?php echo e(route('konsultasi')); ?>" style="font-size: 13px !important">KONSULTASI</a>
        </li>
        <?php if(Auth::user() != null): ?>
        <li>
            <a href="#" style="font-size: 13px !important"">AKUN <span class="fa fa-angle-down "></a>
            <ul class="submenu">
                <li><a href="<?php echo e(route('profil')); ?>">Edit Profil</a></li>
                <li><a href="<?php echo e(route('kirim-tulisan')); ?>">Kirim Tulisan</a></li>
                <li><a href="<?php echo e(url('ketentuan-tulisan')); ?>">Ketentuan Tulisan</a></li>
                <li><a href="" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Log Out</a></li>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </ul>
        </li>
        <?php else: ?>
        <li>
            <a href="#" style="font-size: 13px !important"">AKUN <span class="fa fa-angle-down "></a>
            <ul class="submenu">
                <li><a href="<?php echo e(route('kirim-tulisan')); ?>">Kirim Tulisan</a></li>
                <li><a href="<?php echo e(url('ketentuan-tulisan')); ?>">Ketentuan Tulisan</a></li>
                <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
            </ul>
        </li>
        <?php endif; ?>
        <li style="margin-left: -40px">
            <form class="form-row d-flex justify-content-center md-form form-sm mt-0" action="<?php echo e(route('hasil-pencarian')); ?>" method="GET">
                <input type="text" class="row bdr-5 single-input-primary2 ml-5 w-75" name="hasil_search" style="margin-top: -8px; height: 30px;" placeholder="Search">
                <div class="input-group-prepend">
                    <button type="submit" style="border: none; background: black; height: 30px; margin-top: -8px; border-radius: 0px 5px 5px 0px">
                        <i class="fa fa-search" style="color: white"></i> 
                    </button>
                </div>
            </form>
        </li>
    </ul>
</nav>
<?php /**PATH E:\xampp\htdocs\2020\pundi\resources\views/masterPages/headers/nav-menu.blade.php ENDPATH**/ ?>