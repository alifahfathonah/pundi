
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('masterPages.headers.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="blog_area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mb-5 mb-lg-0">
                <div class="blog_left_sidebar">
                    <?php echo $__env->make('masterPages.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div>
                        <form action="<?php echo e(route('kirim-tulisan.tambah', Auth::user()->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('POST')); ?>

                            <p class="f-blk fs-30 f-b">Upload Tulisan</p>
                            <div class="m-t-30">
                                <label for="" class="f-b fs-17">JUDUL ARTIKEL<span class="text-danger ml-1">*</span></label>
                                <input type="text" class="input single-input-primary border bdr-5 col-md-12" name="judul" id="judul" value="<?php echo e(old('judul')); ?>" required="" oninvalid="this.setCustomValidity('Judul artikel tidak boleh kosong')" oninput="setCustomValidity('')"/>
                            </div>
                            <div class="m-t-15">
                                <label for="" class="f-b fs-17">KATEGORI<span class="text-danger ml-1">*</span></label><br>
                                <div class="row">
                                    <select name="kategori_id" id="kategori_id" value="<?php echo e(old('kategori_id')); ?>" class="kategori input single-input-primary border select" required="" oninvalid="this.setCustomValidity('Kategori tidak boleh kosong')" oninput="setCustomValidity('')">
                                        <option value="0">Pilih Kategori</option>
                                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($i->id); ?>" <?php if($kategori_id == $i->id): ?> selected="selected"<?php endif; ?>>
                                                <?php echo e($i->n_kategori); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <select name="sub_kategori_id" id="sub_kategori_id" class="kategori1 input single-input-primary border select" required>
                                    </select>
                                </div>
                            </div>
                            <div class="m-t-15">
                                <label for="" class="f-b fs-17">ISI ARTIKEL<span class="text-danger ml-1">*</span></label>
                                <?php echo $__env->make('masterPages.summernote', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="alert alert-dismissible" id="message" role="alert"></div>
                            <div style="margin-top: -20px">
                                <label for="" class="f-b fs-17">GAMBAR UNGGULAN <span class="text-danger ml-1">*</span></label><br>
                                <input type="file" name="gambar" id="gambar" onchange="tampilkanPreview(this,'preview')">
                                <label for="file" class="js-labelFile">
                                    <span class="js-fileName"></span>
                                </label>
                                <br>
                                <img width="300" class="rounded img-fluid d-block" id="preview" alt="" style="margin-top: 10px"/>
                            </div>
                            <div class="m-t-10">
                                <label for="" class="f-b fs-17">TAGS</label>
                                <input type="text" class="input single-input-primary border bdr-5 col-md-12" value="<?php echo e(old('tag')); ?>" name="tag" id="tag"/>
                                <i class="fs-12 f-red">Pisahkan dengan koma ( , )</i>
                            </div>
                            <button class="genric-btn primary bdr-5 m-t-20 " type="submit"  value="Log in">KirimTulisan</button>
                            <hr>
                        </form>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('masterPages.right-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</section>
<?php echo $__env->make('masterPages.footers.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<script type="text/javascript">
    // file name preview
    (function () {
        'use strict';
        $('.input-file').each(function () {
            var $input = $(this),
                $label = $input.next('.js-labelFile'),
                labelVal = $label.html();

            $input.on('change', function (element) {
                var fileName = '';
                if (element.target.value) fileName = element.target.value.split('\\').pop();
                fileName ? $label.addClass('has-file').find('.js-fileName').html(fileName) : $label
                    .removeClass('has-file').html(labelVal);
            });
        });
    })();

    // image preview
    function tampilkanPreview(gambar, idpreview) {
        var gb = gambar.files;
        for (var i = 0; i < gb.length; i++) {
            var gbPreview = gb[i];
            var imageType = /image.*/;
            var preview = document.getElementById(idpreview);
            var reader = new FileReader();
            if (gbPreview.type.match(imageType)) {
                preview.file = gbPreview;
                reader.onload = (function (element) {
                    return function (e) {
                        element.src = e.target.result;
                    };
                })(preview);
                reader.readAsDataURL(gbPreview);
            } else {
                Swal.fire(
                    'Tipe file tidak boleh',
                    'Harus format gambar',
                    'error'
                )
            }
        }
    }

    // Sub Kategori
    $(document).ready(function(){
        $('#kategori_id').change(function(){ 
            var id=$(this).val();
            $.ajax({
                url : "<?php echo e(route('kirim-tulisan.subKegiatanByKegiatan', ':id')); ?>".replace(':id', id),
                method : "GET",
                data : {id: id},
                async : true,
                dataType : 'json',
                success: function(data){
                    var html = '';
                    var i;
                    if (data) {
                        $.each(data, function(index, value){
                            html += '<option value='+value.id+'>'+value.n_sub_kategori+'</option>'; 
                        });
                        $('#sub_kategori_id').html(html);
                    } else {
                        $('#sub_kategori_id').html(html);
                    }   
                }
            });
            return false;
        }); 
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\2020\pundi\resources\views/pages/post-artikel.blade.php ENDPATH**/ ?>