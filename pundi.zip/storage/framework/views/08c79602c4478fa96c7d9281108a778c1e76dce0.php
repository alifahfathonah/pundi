<div class="mt-5">
    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link active f-orange" id="home-tab" data-toggle="tab" href="#artikel">Artikel</a>
        </li>
        <li class="nav-item">
            <a class="nav-link f-orange" id="profile-tab" data-toggle="tab" href="#info">Info</a>
        </li>
    </ul>
    <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show active" id="artikel" role="tabpanel">
            <ul class="list-group list-group-flush">
                <?php $no = 0;?>
                <?php $__currentLoopData = $post->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $no++ ;?>
                <li class="list-group-item">
                    <a class="text-black" style="margin-left: -20px !important" href="<?php echo e(route('artikel') .'?post='.$i->id); ?>">
                    <?php echo e($no); ?>. &nbsp;<?php echo e($i->judul); ?>

                    </a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php if($post->count() > 10): ?>
            <span class="bdr-5 fs-11 f-b m-r-10 sub-kategori-card">
                <a class="text-center" href="#">Lihat Semua Artikel</a>
            </span>
            <?php endif; ?>
        </div>
        <div class="tab-pane fade" id="info" role="tabpanel">
            info
        </div>
    </div>
</div><?php /**PATH E:\xampp\htdocs\2020\pundi\resources\views/pages/profil/navigation.blade.php ENDPATH**/ ?>